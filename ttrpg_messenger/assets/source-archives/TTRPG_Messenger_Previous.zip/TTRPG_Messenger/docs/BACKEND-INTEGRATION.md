# Backend Integration

## Configured deployment

The frontend sends JSON requests to:

`https://script.google.com/macros/s/AKfycbxxcMVPpAaa8bbVguBVwdRu7B1QkvGxgf5Gq2D-lLQUFoaAsBM3hhS6IDBsK9bdDbmdlA/exec`

Apps Script library:

- ID: `18ET55A9uVNx3IUzoAM_eRj8v7jqagPgjVdxil3P1SoUqrFnnAJp6CjVr`
- Version: `1`

## Request format

Every request uses `POST` with `Content-Type: text/plain;charset=utf-8`. This avoids a browser CORS preflight that Google Apps Script ContentService cannot customize.

Unauthenticated example:

```javascript
fetch(BACKEND_URL, {
  method: "POST",
  headers: { "Content-Type": "text/plain;charset=utf-8" },
  body: JSON.stringify({
    action: "login",
    email: "player@example.com",
    password: "password"
  })
});
```

Authenticated calls add the session token to the JSON body:

```json
{
  "action": "listServers",
  "token": "SESSION_TOKEN"
}
```

Successful responses use `{ "ok": true, "data": ... }`. Errors use `{ "ok": false, "error": { "code": "...", "message": "..." } }`.

## Frontend API coverage

The interface uses the deployed backend for:

- Authentication and profiles
- Campaign server, member, role, channel, and invite management
- Channel messages, direct messages, reactions, pins, attachments, typing, search, and read state
- Presence, polling events, and notifications used by the interface
- Voice state and direct-call state
- WebRTC offer, answer, ICE, hangup, and acknowledgement signaling
- Character personas, dice rolls, and audit logs

## WebRTC flow

1. A player joins a voice/video channel or accepts a direct call.
2. The browser requests microphone/camera permission.
3. The frontend calls `joinVoice`, `startCall`, or `acceptCall`.
4. Each browser establishes `RTCPeerConnection` links with room peers.
5. SDP and ICE data are exchanged through `sendRtcSignal`, `pollRtcSignals`, and `ackRtcSignals`.
6. Audio/video media travels directly between browsers.

For production reliability, configure `RTC_ICE_SERVERS_JSON` in Apps Script Script Properties with STUN and TURN entries. Example shape:

```json
[
  { "urls": ["stun:stun.example.net:3478"] },
  {
    "urls": ["turn:turn.example.net:3478?transport=udp", "turns:turn.example.net:5349?transport=tcp"],
    "username": "TURN_USERNAME",
    "credential": "TURN_CREDENTIAL"
  }
]
```

Do not publish permanent TURN credentials in the HTML file.

## Changing the deployment

Edit the `CONFIG` object near the beginning of `ttrpg-messenger.html`:

```javascript
const CONFIG = Object.freeze({
  backendUrl: "NEW_WEB_APP_URL",
  libraryUrl: "NEW_LIBRARY_URL",
  libraryId: "NEW_LIBRARY_ID",
  libraryVersion: "1"
});
```
