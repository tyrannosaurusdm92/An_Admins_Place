# Feature Map

## Campaign creation and invitations

The first registered user can create a campaign and immediately receives a private invitation link. Invite managers can create additional links with expiration periods and optional use limits, copy them, and revoke them.

## Campaign spaces

A newly created campaign receives default areas suited to a TTRPG group:

- General table chat
- In-character roleplay
- Out-of-character discussion
- Announcements
- Handouts
- Main voice room
- Optional video/session-sharing room

Creators and permitted moderators can add, edit, and remove channels and organize them by category.

## Communication

Channel and direct-message communication includes:

- Standard, in-character, out-of-character, roll, handout, and system message types
- Replies, edits, soft deletion, pins, reactions, search, typing state, and read markers
- File uploads backed by Apps Script/Drive storage
- Direct conversations and direct/group calls
- Presence indicators and polling-driven live updates

## TTRPG tools

- Character personas can be created per campaign and selected as the active speaker identity.
- Dice expressions are rolled by the backend so posted results are auditable by the table.
- Handout channels provide a dedicated place for maps, clues, character sheets, and reference files.

## Voice and video

- Voice and video channels
- Direct-message calls
- Microphone mute and deafen
- Spacebar push-to-talk mode
- Camera toggle
- Screen sharing
- Peer-to-peer WebRTC media with Apps Script signaling

Voice requires HTTPS or localhost. TURN is strongly recommended for production groups connecting from different network types.

## Roles and safety

Backend permissions cover campaign administration, channel/message management, kick/ban actions, voice access, streaming, invite creation, role management, attachments, mentions, personas, dice, handouts, and audit-log access.

The campaign creator remains the owner. Moderation controls are shown only when the current player has the relevant permission.
