# Tablegate — TTRPG Messenger

Tablegate is a single-page, invite-only campaign messenger built from the strongest functional patterns in the three supplied Discord-style projects and redesigned specifically for tabletop roleplaying groups.

The application is already wired to the supplied Google Apps Script deployment:

- Web app: `https://script.google.com/macros/s/AKfycbxxcMVPpAaa8bbVguBVwdRu7B1QkvGxgf5Gq2D-lLQUFoaAsBM3hhS6IDBsK9bdDbmdlA/exec`
- Apps Script library: `18ET55A9uVNx3IUzoAM_eRj8v7jqagPgjVdxil3P1SoUqrFnnAJp6CjVr`, version `1`

## Open the messenger

For text-only testing, you can open `ttrpg-messenger.html` directly in a browser. Microphone, camera, and screen-sharing APIs normally require a secure origin, so use localhost or HTTPS for voice features.

### Windows localhost launcher

Double-click `run-local.bat`, or right-click `run-local.ps1` and choose **Run with PowerShell**. Then open:

`http://localhost:8787/ttrpg-messenger.html`

The launcher uses Python's built-in static server. Python 3 must be installed and available as `py` or `python`.

## Recommended deployment

Upload the folder to any HTTPS static host, preserving `ttrpg-messenger.html` as the entry page. GitHub Pages, Netlify, Cloudflare Pages, and similar static hosts work because all persistent application data is handled by the supplied Apps Script backend.

Invite links contain the campaign invite code in the page URL, for example:

`https://your-site.example/ttrpg-messenger.html?invite=INVITE_CODE`

The creator generates these from **Campaign menu → Invite players**. Only a registered player with a valid active invite can join an invite-only campaign.

## Included features

- Creator-owned campaign servers with invitation links, expiration dates, and use limits
- Text, announcement, handout, voice, and video channels organized into categories
- Roles, permissions, member moderation, and audit logs
- Direct messages and direct/group call support through the backend API
- Replies, editing, deletion, pins, reactions, typing indicators, unread markers, search, and file attachments
- TTRPG character personas and server-audited dice rolls
- Browser WebRTC voice, camera, screen sharing, mute, deafen, and push-to-talk
- Responsive desktop and mobile layout
- Polling-based real-time updates compatible with Google Apps Script

## Voice networking note

Google Apps Script authorizes rooms and exchanges WebRTC offer/answer/ICE messages, but it does not carry the live audio or video stream. Media travels peer-to-peer between players. Public STUN may be enough for many networks; a TURN service should be configured in the backend property `RTC_ICE_SERVERS_JSON` for reliable connections across restrictive NATs, institutional Wi-Fi, carrier networks, or firewalls.

## Folder contents

- `ttrpg-messenger.html` — complete frontend, with CSS and JavaScript embedded
- `backend/ttrpgmessenger.gs` — reference copy of the backend implementation used by the deployed endpoint
- `docs/BACKEND-INTEGRATION.md` — deployment and API integration notes
- `docs/FEATURES.md` — feature map and role behavior
- `THIRD_PARTY_NOTICES.md` — notices for the supplied source projects
- `run-local.bat`, `run-local.ps1` — local HTTPS-compatible browser-origin launcher via localhost

## Important backend setup

The supplied web app must remain deployed as **Execute as: Me** and accessible to the intended users. The backend should have already had `setupTtrpgMessenger()` run once. If the deployment is replaced, update `CONFIG.backendUrl` near the top of the script in `ttrpg-messenger.html`.
