$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot
$Port = 8787
$Url = "http://localhost:$Port/ttrpg-messenger.html"

Write-Host "Starting Tablegate at $Url" -ForegroundColor Green
Start-Process $Url

if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3 -m http.server $Port --bind 127.0.0.1
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    & python -m http.server $Port --bind 127.0.0.1
} else {
    Write-Host "Python 3 was not found. Install Python, then run this launcher again." -ForegroundColor Red
    Read-Host "Press Enter to close"
    exit 1
}
